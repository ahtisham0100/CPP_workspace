#include<iostream>
#include <cmath>
using namespace std;
int main()
{
cout<<" \t \t \t \t WELCOME TO CARSnLOANS " << endl;
int totalcost, numberofmonths, downpayment ,payableamount;
cout<<"ENTER THE TOTAL COST OF CAR : ";
cin>>totalcost;
cout<<"ENTER DOWNPAYMENT : " ;
cin>>downpayment;
cout<<"ENTER THE NUMBE OF MONTHS IN WHICH YOU WANT TO PAY REMAINING AMOUNT : " ;
 cin>>numberofmonths;
 payableamount =totalcost - downpayment ;

//if no of months is less than 12
 if(numberofmonths<= 12 ) 
{
    payableamount = payableamount + (payableamount * 10/100 ) ;
    cout<<"PAYABLE AMOUNT = " << payableamount << endl;
    cout<<"PER MONTH INSTALLEMENT = " <<payableamount/numberofmonths << endl;
}
//if no of months is > 12 and <= 24
else if (numberofmonths>12 && numberofmonths <=24 )
{
    payableamount = payableamount + (payableamount * 15/100 ) ;
    cout<<"PAYABLE AMOUNT = " << payableamount << endl;
     cout<<"PER MONTH INSTALLEMENT = " <<payableamount/numberofmonths << endl ;
} 
//if no of months>24 & <= 36
else if (numberofmonths> 24 && numberofmonths <= 36 )
{
    payableamount = payableamount + (payableamount * 20/100 ) ;
    cout<<"PAYABLE AMOUNT = " << payableamount << endl;
     cout<<"PER MONTH INSTALLEMENT = " <<payableamount/numberofmonths <<endl;
}
//if no of months>36 & <= 48
else if (numberofmonths> 36 && numberofmonths <= 48 )
{
    payableamount = payableamount + (payableamount * 25/100 ) ;
    cout<<"PAYABLE AMOUNT = " << payableamount << endl;
     cout<<"PER MONTH INSTALLEMENT = " <<payableamount/numberofmonths  << endl ;
}
//if no of months>48 & <= 60
else if (numberofmonths> 48 && numberofmonths <= 60 )
{
    payableamount = payableamount + (payableamount * 30/100 ) ;
    cout<<"PAYABLE AMOUNT = " << payableamount << endl;
     cout<<"PER MONTH INSTALLEMENT = " <<payableamount/numberofmonths <<endl;
}
else if (numberofmonths>60)
{
    cout<<"PLEASE MIND THAT INSTALLEMENTS MONTHS CAN NOT EXCEED 60 " << endl;
    
} 



system("pause");
    return 0;
}
