#include <iostream>
using namespace std;
int main(){
	
    cout << "MCS                      \a" << endl ; // \a is used for producing beeping sound
	cout << "       MCS               \a" << endl ;
	cout << "             MCS         \a" << endl ;
	cout << "                   MCS   \a" << endl ;
return 0 ;
}

