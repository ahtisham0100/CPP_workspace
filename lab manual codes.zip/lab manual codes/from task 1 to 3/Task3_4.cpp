#include <iostream>
using namespace std;
int main(){
    cout << "This is a test. \a\n " ; //\a for beep sound \n for ending line
    cout << "He asked,\a \"How are you doing?\" \a\n " ; //\" for printing words in Commas
    cout << "\"Education is the most powerful weapon \awhich you can use to 'CHANGE'\a the world.\"\a " ;
return 0 ;
}

