#include <iostream>
using namespace std;
int main(){

    int a ; 
    float b ;
    char c ;
    cout << "Enter Integer value: " ; cin >> a ; 
    cout << "Enter float value: " ; cin >> b ;
    cout << "Enter character value: " ; cin >> c ;
    cout << "******* You have entered the following values ******* \n " ;
    cout << "Integer value is: " << a << endl ;
    cout << "Float value is: " << b << endl ;
    cout << "Character value is: " << c << endl ;
return 0 ;
}

